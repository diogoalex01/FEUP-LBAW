


<?php $__env->startSection('content'); ?>

<!-- Page Content -->
<div class="container">

    <div class="row" style="padding: 20px 0px;">

        <!-- Aside -->
        <div class="col-md-3 aside ">

            <!-- My Categories -->
            <div class="card aside-container sticky-top">
                <h5 class="card-header aside-container-top" style="border: 1px solid rgba(76, 25, 27); border-radius: 2px; background-color: rgb(76, 25, 27);">
                </h5>
                <div class="card-body">
                    <div class="row">
                        <div class="col justify-content-start">
                            <div id="home" class="nav-border-active">
                                Home
                            </div>
                            
                                <div id="popular" class="nav-border">Popular</div>
                            
                            
                                <div id="trending" class="nav-border">Trending</div>
                            
                            
                                <div id="universities" class="nav-border" style="border-bottom: 0px;">Universities</div>
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <!-- Posts Column -->
        <div class="col-md-9">

            <?php if(Auth::check()): ?>

                <!-- New Post -->
                 <a href=<?php echo e(route('new_post')); ?>>
                    <div class="mt-4 mt-md-1 card mb-4 mr-md-2 mr-lg-4 post-container">
                        <div class="card-body">
                            <div class="row" style="font-size: 0.45rem;">
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Write your own article">
                                </div>
                                <div class="col-1 pl-0 my-auto">
                                    <i class="fas fa-plus-circle fa-4x"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                 </a> 

            <?php endif; ?>

            <!-- Posts -->
            <?php echo $__env->renderEach('partials.homePost', $posts, 'post'); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jonas/Desktop/lbaw2076/resources/views/pages/home.blade.php ENDPATH**/ ?>