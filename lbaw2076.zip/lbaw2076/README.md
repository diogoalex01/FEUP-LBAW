# lbaw2076

## Tema 1 - Collaborative News

This project aims to provide an online collaborative news platform. People can post about their favorite topics and share some knowledge with the community. Sharing is caring.

## Membros do grupo:

* Ana Mafalda Costa Santos, up201706791@fe.up.pt
* Diogo Alexandre Silva, up201706892@fe.up.pt
* João Henrique Luz, up201703782@fe.up.pt
* Liliana Almeida, up201706908@fe.up.pt

***
GROUP2076, 18/02/2020
